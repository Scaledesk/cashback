<form action="<?=(base_url().'Coupon_control/add_coupon')?>" method="post">
  name:<input type="text" name="coupon_name" />
 Company  name:<input type="text" name="coupon_company" />
 :<input type="text" name="coupon_name" />
</form>
