﻿
  
  <!--start of middle sec-->
  <div class="middle-sec wow fadeIn" data-wow-offset="10" data-wow-duration="2s">
    <div id="particles">
      <div id="countdown-soon" class="wow fadeInDown text-center">
        <div class="update">
          <h2 class="text-primary text-uppercase">WE WILL COME SOON</h2>
          <h6 class="text-primary text-uppercase">Stay Tuned For Updates</h6>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. </p>
        </div>
        <div class="coming-soon">
          <p><span class="days">00</span> <span class="timeRefDays">days</span></p>
          <p><span class="hours">00</span> <span class="timeRefHours">hours</span></p>
          <p><span class="minutes">00</span> <span class="timeRefMinutes">min</span></p>
          <p><span class="seconds">00</span> <span class="timeRefSeconds">sec</span></p>
        </div>
      </div>
    </div>
  </div>
  <!--end of middle sec--> 
  
 