<!--start of middle sec-->
  <div class="middle-sec wow fadeIn" data-wow-offset="10" data-wow-duration="2s">
    <div class="page-header">
      <div class="container text-center">
        <h2 class="text-primary text-uppercase">Welcome Admin</h2>

      </div>
    </div>
    <section class="container">
      <div class="row">
         <div class="col-sm-12 equal-height-container">
          <div class="row">
            <div class="col-sm-4 col-md-3 sub-data-left sub-equal">
              <div id="sticky">
                <section class="col-sm-12">
                  <!-- <h5 class="sub-title text-info text-uppercase">order summary</h5> -->
                  <ul class="list-group summary">
                  <a href="<?=(base_url().'Product/home_page_setting/')?>"><li class="list-group-item text-uppercase"><strong>Home pages Setting </strong></li></a>
                    <a href="<?=(base_url().'Product/product_page/')?>"><li class="list-group-item text-uppercase"><strong> Add Product </strong></li></a>
                    <a href="<?=(base_url().'Product/display_product/')?>"><li class="list-group-item text-uppercase"><strong> Show Product </strong></li></a>
                    <a href="<?=(base_url().'Product/category/')?>"><li class="list-group-item text-uppercase"><strong>Add Category</strong></li></a>
                    <a href="<?=(base_url().'Product/show_category/')?>"><li class="list-group-item text-uppercase"><strong>Show Category</strong></li></a>
                    <a href="<?=(base_url().'User/add_wallet')?>"><li class="list-group-item text-uppercase"><strong>Add Wallet<span class="pull-right"></span></strong></li></a>
                    <a href="<?=(base_url().'Coupon_control/add_coupon/')?>"><li class="list-group-item text-uppercase"><strong>Add Coupon<span class="pull-right"></span></strong></li></a>
                    <a href="<?=(base_url().'Coupon_control/view_coupon_admin/')?>"><li class="list-group-item text-uppercase"><strong>View Coupon<span class="pull-right"></span></strong></li></a>
                    <a href="<?=(base_url().'Store_control/add_store/')?>"><li class="list-group-item text-uppercase"><strong>Add Store<span class="pull-right"></span></strong></li></a>
                    <a href="<?=(base_url().'Store_control/view_store/')?>"><li class="list-group-item text-uppercase"><strong>View Store<span class="pull-right"></span></strong></li></a>
                    <a href="<?=(base_url().'product/display_product/')?>"><li class="list-group-item text-uppercase"><strong>Display Product<span class="pull-right"></span></strong></li></a>
                  </ul>
                </section>

              </div>
            </div>
